# Retail Sales SQL Analysis

## 📌 Project Overview

This project demonstrates SQL skills through a realistic retail sales analysis scenario. The objective is to transform transactional data into business insights around revenue, customers, products, regions and profitability.

The project is designed as a portfolio project for a **Data Analyst** role and focuses on practical SQL rather than isolated syntax exercises.

## 🛠️ Tools & Technologies

- PostgreSQL
- SQL
- CTEs
- Window Functions
- Aggregations
- Joins
- CASE expressions
- Date Functions
- GitHub

## 📂 Dataset

The database contains four tables:

| Table | Description |
|---|---|
| `customers` | Customer demographics and location |
| `products` | Product catalogue and pricing |
| `orders` | Order-level transactions |
| `order_items` | Products, quantities and discounts within each order |

The generated dataset contains approximately **1,200 customers, 60 products, 7,000 orders and 20,000+ order-item records**.

## 📊 Business Questions

The analysis answers questions including:

1. What is total revenue?
2. What are the monthly revenue trends?
3. Which regions generate the most revenue?
4. What is the average order value?
5. Which product categories perform best?
6. Who are the top customers by revenue?
7. What is the repeat-customer rate?
8. Which products generate the most revenue?
9. What are the top 3 products in each category?
10. Which products generate the most gross profit?
11. What is month-over-month revenue growth?
12. What is the cumulative revenue over time?
13. What percentage of revenue does each product contribute?
14. How do customers rank by revenue?
15. Which customers are the strongest according to an RFM-style score?

## 🧠 SQL Skills Demonstrated

### Beginner
- SELECT
- WHERE
- ORDER BY
- DISTINCT
- GROUP BY
- HAVING
- COUNT / SUM / AVG

### Intermediate
- INNER JOIN
- LEFT JOIN
- CASE
- Date functions
- Subqueries
- Data-quality checks

### Advanced
- CTEs
- `LAG()`
- `RANK()`
- `DENSE_RANK()`
- `NTILE()`
- Running totals
- Percentage-of-total calculations
- Month-over-month growth
- RFM-style segmentation

## 📁 Project Structure

```text
Retail-Sales-SQL-Analysis/
│
├── data/
│   ├── customers.csv
│   ├── products.csv
│   ├── orders.csv
│   └── order_items.csv
│
├── sql/
│   ├── 00_schema.sql
│   ├── 01_data_exploration.sql
│   ├── 02_data_cleaning.sql
│   ├── 03_sales_analysis.sql
│   ├── 04_customer_analysis.sql
│   ├── 05_product_analysis.sql
│   └── 06_advanced_analysis.sql
│
├── analysis/
│   └── business_insights.md
│
└── README.md
```

## 🚀 How to Run

1. Create a PostgreSQL database.
2. Run `sql/00_schema.sql`.
3. Import the four CSV files from the `data` folder.
4. Run the SQL scripts in numerical order.
5. Review the results and document the business insights.

## 💡 Business Value

The project demonstrates how SQL can be used to move from raw transactional data to decisions around:

- Revenue growth
- Customer retention
- Product performance
- Regional performance
- Profitability
- Marketing prioritisation

## 👤 Author

**Eldin B. Joseph**

Data Analyst | SQL | Excel | Power Query | Tableau
